using System;
using System.Windows.Forms;

namespace TrominoTiler
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new TrominoForm());
        }
    }
}
