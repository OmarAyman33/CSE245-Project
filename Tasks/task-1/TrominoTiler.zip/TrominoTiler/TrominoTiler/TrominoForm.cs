using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace TrominoTiler
{
    public class TrominoForm : Form
    {
        TextBox txtN, txtRow, txtCol;
        Button btnTile;
        Panel boardPanel;

        int[,] board;
        int trominoId;
        int size;
        readonly Color[] trominoColors = { Color.Red, Color.Green, Color.Blue };

        public TrominoForm()
        {
            Text = "Tromino Tiler";
            Width = 600;
            Height = 700;

            var lblN = new Label { Text = "n (power of 2):", AutoSize = true, Top = 15, Left = 15 };
            txtN = new TextBox { Top = lblN.Top, Left = 120, Width = 50, Text = "3" };

            var lblR = new Label { Text = "Missing Row:", AutoSize = true, Top = 45, Left = 15 };
            txtRow = new TextBox { Top = lblR.Top, Left = 120, Width = 50, Text = "1" };

            var lblC = new Label { Text = "Missing Col:", AutoSize = true, Top = 75, Left = 15 };
            txtCol = new TextBox { Top = lblC.Top, Left = 120, Width = 50, Text = "1" };

            btnTile = new Button { Text = "Tile", Top = 110, Left = 15 };
            btnTile.Click += BtnTile_Click;

            boardPanel = new Panel
            {
                Top = 150,
                Left = 15,
                AutoScroll = true,
                BorderStyle = BorderStyle.FixedSingle,
                Width = ClientSize.Width - 30,
                Height = ClientSize.Height - 180,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            Controls.AddRange(new Control[] { lblN, txtN, lblR, txtRow, lblC, txtCol, btnTile, boardPanel });
        }

        private void BtnTile_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtN.Text, out int n) || n < 1)
            {
                MessageBox.Show("Enter a valid integer n >= 1");
                return;
            }

            size = 1 << n; // 2^n

            if (!int.TryParse(txtRow.Text, out int mr) ||
                !int.TryParse(txtCol.Text, out int mc) ||
                mr < 1 || mr > size || mc < 1 || mc > size)
            {
                MessageBox.Show($"Row/Col must be between 1 and {size}");
                return;
            }

            // Initialize
            board = new int[size, size];
            trominoId = 0;

            // Mark missing cell as -1
            board[mr - 1, mc - 1] = -1;

            // Tile
            LocateTromino(0, size - 1, 0, size - 1, mr - 1, mc - 1);

            // Color
            ColorBoard();

            // Display
            BuildBoardUI();
        }

        // Recursive tiling
        private void LocateTromino(int r0, int r1, int c0, int c1, int mr, int mc)
        {
            int s = r1 - r0 + 1;
            if (s == 1) return;

            int rm = (r0 + r1) / 2, cm = (c0 + c1) / 2;
            int quad;

            if (mr <= rm)
                quad = (mc > cm) ? 1 : 2;
            else
                quad = (mc <= cm) ? 3 : 4;

            trominoId++;

            // Place central L-tromino
            if (quad == 1)
            {
                board[rm, cm] = trominoId;
                board[rm + 1, cm] = trominoId;
                board[rm + 1, cm + 1] = trominoId;
            }
            else if (quad == 2)
            {
                board[rm, cm + 1] = trominoId;
                board[rm + 1, cm] = trominoId;
                board[rm + 1, cm + 1] = trominoId;
            }
            else if (quad == 3)
            {
                board[rm, cm] = trominoId;
                board[rm, cm + 1] = trominoId;
                board[rm + 1, cm + 1] = trominoId;
            }
            else // quad 4
            {
                board[rm, cm] = trominoId;
                board[rm, cm + 1] = trominoId;
                board[rm + 1, cm] = trominoId;
            }

            // Recurse into 4 quadrants
            // Top-right
            LocateTromino(r0, rm, cm + 1, c1,
                quad == 1 ? mr : rm,
                quad == 1 ? mc : cm + 1);

            // Top-left
            LocateTromino(r0, rm, c0, cm,
                quad == 2 ? mr : rm,
                quad == 2 ? mc : cm);

            // Bottom-left
            LocateTromino(rm + 1, r1, c0, cm,
                quad == 3 ? mr : rm + 1,
                quad == 3 ? mc : cm);

            // Bottom-right
            LocateTromino(rm + 1, r1, cm + 1, c1,
                quad == 4 ? mr : rm + 1,
                quad == 4 ? mc : cm + 1);
        }

        // Build adjacency graph and greedy color
        private void ColorBoard()
        {
            // STEP 1: Build adjacency graph
            var adj = new Dictionary<int, HashSet<int>>();

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    int id = board[i, j];
                    if (id <= 0) continue;

                    if (!adj.ContainsKey(id))
                        adj[id] = new HashSet<int>();

                    foreach (var d in new (int di, int dj)[] { (-1, 0), (1, 0), (0, -1), (0, 1) })
                    {
                        int x = i + d.di, y = j + d.dj;
                        if (x < 0 || x >= size || y < 0 || y >= size) continue;

                        int nid = board[x, y];
                        if (nid > 0 && nid != id)
                        {
                            adj[id].Add(nid);
                            if (!adj.ContainsKey(nid))
                                adj[nid] = new HashSet<int>();
                            adj[nid].Add(id);
                        }
                    }
                }
            }

            // STEP 2: Greedy coloring
            var colorMap = new Dictionary<int, int>();
            foreach (var id in adj.Keys)
                colorMap[id] = -1;

            foreach (var kv in adj)
            {
                bool[] used = new bool[3];
                foreach (var nb in kv.Value)
                {
                    int c = colorMap[nb];
                    if (c >= 0 && c < 3) used[c] = true;
                }

                int pick = 0;
                while (pick < 3 && used[pick]) pick++;
                if (pick >= 3) pick = 0;

                colorMap[kv.Key] = pick;
            }

            // STEP 3: Overwrite board IDs with color index
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    int id = board[i, j];
                    if (id > 0 && colorMap.TryGetValue(id, out int c))
                        board[i, j] = c + 1;
                }
            }
        }

        // Draw the grid of colored Panels
        private void BuildBoardUI()
        {
            boardPanel.Controls.Clear();
            boardPanel.SuspendLayout();

            int cellSize = Math.Min(
                (boardPanel.ClientSize.Width - 20) / size,
                (boardPanel.ClientSize.Height - 20) / size);

            if (cellSize < 1) cellSize = 1;

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    var cell = new Panel
                    {
                        Width = cellSize,
                        Height = cellSize,
                        Left = j * cellSize,
                        Top = i * cellSize,
                        BorderStyle = BorderStyle.FixedSingle
                    };

                    int val = board[i, j];
                    Color bg;
                    switch (val)
                    {
                        case -1: bg = Color.Black;  break;
                        case  1: bg = trominoColors[0]; break;
                        case  2: bg = trominoColors[1]; break;
                        case  3: bg = trominoColors[2]; break;
                        default: bg = Color.White;  break;
                    }
                    cell.BackColor = bg;

                    boardPanel.Controls.Add(cell);
                }
            }

            boardPanel.ResumeLayout();
        }
    }
}
